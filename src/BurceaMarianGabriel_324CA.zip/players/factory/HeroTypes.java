package players.factory;

public enum HeroTypes {
    PYROMANCER, KNIGHT, WIZARD, ROGUE
}
