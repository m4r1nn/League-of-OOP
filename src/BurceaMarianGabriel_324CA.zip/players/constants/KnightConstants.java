package players.constants;

public class KnightConstants {
    public static final int defaultHP = 900;
    public static final int bonusHPperLevel = 30;
    public static final int firstBaseDamage = 200;
    public static final int firstDamageBonusPerLevel = 30;
    public static final int HPprocentLimit = 20;
    public static final int MaxHPprocentLimit = 40;
    public static final int secondBaseDamage = 100;
    public static final int secondDamageBonusPerLevel = 40;
}
