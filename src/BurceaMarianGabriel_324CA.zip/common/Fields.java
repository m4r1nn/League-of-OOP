package common;

public enum Fields {
    LAND, VOLCANIC, DESERT, WOODS
}
